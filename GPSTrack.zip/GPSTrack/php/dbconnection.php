<?php
$connect_todb = new mysqli('smtdb.cbfnol3hymbz.us-west-2.rds.amazonaws.com:3306','smtadmin','smtpassw','smtdb');
